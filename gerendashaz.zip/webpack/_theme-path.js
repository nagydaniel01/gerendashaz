const themePath = 'assets';

module.exports = themePath;
