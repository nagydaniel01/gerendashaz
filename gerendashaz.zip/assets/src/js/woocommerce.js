/*
document.addEventListener('DOMContentLoaded', function() {
    if ( typeof jQuery !== 'undefined' && jQuery.fn.zoom ) {
        jQuery('.woocommerce-product-gallery').each(function() {
            var gallery = jQuery(this);
            gallery.find('.woocommerce-product-gallery__image').zoom();
        });
    }
});
*/
