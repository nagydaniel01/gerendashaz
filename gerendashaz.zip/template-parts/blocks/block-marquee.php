<?php

defined( 'ABSPATH' ) || exit;

?>

<div class="block block--marquee">
    <div class="container">
        <div class="block__inner">
            <div class="block__track">
                <div class="block__item">
                    15000 Ft feletti vásárlás esetén ingyenes szállítás
                </div>
            </div>
        </div>
    </div>
</div>